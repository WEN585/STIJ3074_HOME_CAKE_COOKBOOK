<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','develope');
define('DB_PASS','neverGiveUp555');
define('DB_NAME','develope_cake');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS);
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>